﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TestCascading.Models;
using TestCascading.Respository.Contract;

namespace TestCascading.Controllers
{
    public class CascadingController : Controller
    {
        private ICascad cascadService;
        public CascadingController(ICascad service) 
        {
             cascadService= service;
        }
        public IActionResult Index()
        {
            return View();
        }
        public IActionResult GetCountry()
        {
            var con = cascadService.GetCountries();
            return Json(con);
        }
        public IActionResult GetState(int id)
        {
            var states = cascadService.GetStates(id);
            return Json(states);
        }
        public IActionResult GetCity(int id)
        {
            var cities = cascadService.GetCities(id);
            return Json(cities);
        }
    }
}
