﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TestCascading.Models;
using TestCascading.Respository.Contract;

namespace TestCascading.Respository.Service
{
    public class CascadService : ICascad
    {
        private AppDbContext dbcon;
        public CascadService(AppDbContext con) 
        {
            dbcon = con;
        }
        public List<City> GetCities(int id)
        {
            var list = dbcon.cities.Where(e => e.State.Id == id).ToList();
            return list;
        }

        public List<Country> GetCountries()
        {
            return dbcon.countries.ToList();
        }

        public List<State> GetStates(int id)
        {
            var list = dbcon.states.Where(e=>e.Country.Id==id).ToList();
            return list;
        }
    }
}
