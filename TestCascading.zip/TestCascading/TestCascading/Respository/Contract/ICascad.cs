﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TestCascading.Models;

namespace TestCascading.Respository.Contract
{
    public interface ICascad
    {
        List<Country> GetCountries();
        List<State> GetStates(int id);
        List<City> GetCities(int id);
    }
}
