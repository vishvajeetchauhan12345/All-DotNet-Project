﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using VishvajeetProject.Models;
using VishvajeetProject.Respository.Contract;

namespace VishvajeetProject.Respository.Service
{
    public class CategoryService : ICategory
    {
        private AppDbContext dbcon;
        public CategoryService(AppDbContext _dbcon)
        {
            dbcon = _dbcon;
        }
        public Category CreateCategory(Category category)
        {
            if (dbcon.categories.Any(e => e.Name == category.Name))
            {
                return null;
            }
            else
            {
                var p = new Category()
                {
                    Name=category.Name
                };
                dbcon.categories.Add(p);
                dbcon.SaveChanges();
                return p;
            }
        }

        public bool DeleteCategory(int id)
        {
            var d1 = dbcon.categories.SingleOrDefault(e => e.Id == id);
            if (d1 != null)
            {
                dbcon.categories.Remove(d1);
                dbcon.SaveChanges();
                return true;
            }
            else
            {
                return false;
            }
        }

        public Category UpdateCategory(int id)
        {
            var d = dbcon.categories.SingleOrDefault(e => e.Id ==id);
            return d;
        }
     
        public bool UpdateCategory(Category category)
        {
            if (dbcon.categories.Any(e => e.Name == category.Name))
            {
                var p = new Category()
                {
                    Name = category.Name
                };

                dbcon.categories.Update(category);
                dbcon.SaveChanges();
                return true;
            }
            else
            {
                return false;
            }
        }
        public List<Category> ViewCategory()
        {
            var list = dbcon.categories.ToList();
            return list;
        }
        public Category ViewCategory(int id)
        {
            var l = dbcon.categories.SingleOrDefault(e => e.Id == id);
            return l;
        }
    }
}
