﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using VishvajeetProject.Models;
using VishvajeetProject.Respository.Contract;

namespace VishvajeetProject.Respository.Service
{
    public class ProductService : IProduct
    {
        private AppDbContext db;
        public ProductService(AppDbContext context) 
        {
            db = context;
        }
        public Product CreateProduct(Product product)
        {
            if (db.products.Any(e => e.Title == product.Title))
            {
                return null;
            }
            else
            {
                var p = new Product()
                {
                    Title = product.Title,
                    Quantity = product.Quantity,
                    Price = product.Price,
                    Image = product.Image,
                    Discription = product.Discription,
                    Category = product.Category
                };
                db.products.Add(p);
                db.SaveChanges();
                return p;
            }
        }

        public bool DeleteProduct(int id)
        {
            var d1 = db.products.SingleOrDefault(e => e.Id == id);
            if (d1 != null)
            {
                db.products.Remove(d1);
                db.SaveChanges();
                return true;
            }
            else
            {
                return false;
            }   
        }
        public Product UpdateP(int id)
        {
            var d = db.products.SingleOrDefault(e=>e.Id==id);
            return d;
        }
        public bool UpdateProduct(Product product)
        {
            if (db.products.Any(e => e.Id ==product.Id))
            {
                var p = new Product()
                {
                    Title = product.Title,
                    Quantity = product.Quantity,
                    Price = product.Price,
                    Discription = product.Discription,
                    Category = product.Category
                };
                
                db.products.Update(product);
                db.SaveChanges();
                return true;
            }
            else 
            {
                return false;
            }
        }

        public Product ViewProduct(int id)
        {
            var l = db.products.SingleOrDefault(e=>e.Id==id);
            return l;
        }
        public List<Product> ViewProduct()
        {
            var list = db.products.ToList();
            return list;
        }
    }
}
