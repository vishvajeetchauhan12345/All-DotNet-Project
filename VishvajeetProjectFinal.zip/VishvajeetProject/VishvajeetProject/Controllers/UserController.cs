﻿using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authentication;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using VishvajeetProject.Models.ViewModel;
using VishvajeetProject.Respository.Contract;
using VishvajeetProject.Utils.Enums;
using System.Security.Claims;
using Microsoft.AspNetCore.Http;
using System.IO;

namespace VishvajeetProject.Controllers
{
    public class UserController : Controller
    {
        private IUser userService;
        private readonly IHostingEnvironment Environment;
        public UserController(IUser user,IHostingEnvironment environment) 
        {
            userService = user;
            Environment = environment;
        }

        public IActionResult Login()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Login(SignIn model)
        {
            if (ModelState.IsValid)
            {
                var result = userService.AuthenticateUser(model);
                if (result == AuthoEnum.SUCCESS)
                {
                    var identity = new ClaimsIdentity(new[] {
                    new Claim(ClaimTypes.Name,model.Email)
                    }, CookieAuthenticationDefaults.AuthenticationScheme);

                    var principle = new ClaimsPrincipal(identity);
                    var login = HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, principle);
                    return RedirectToAction("Index", "Home");
                }
                else if (result == AuthoEnum.FAILED)
                {
                    ModelState.AddModelError(string.Empty, "invalid Login Credentials !");
                    return View();
                }
                else if (result == AuthoEnum.NOTVERIFIED)
                {
                    ModelState.AddModelError(string.Empty, "Your account is stil not active, Please varify Your account !");
                    return View();
                }
                ModelState.AddModelError(string.Empty, "You are not a valid user !");
                return View();
            }
            else
            {
                ModelState.AddModelError(string.Empty, "Please enter login details !");
                return View();
            }   
        }
        public IActionResult Logout()
        {
            var l = HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
            return RedirectToAction("Login");
        }
        /*public IActionResult Index()
        {
            return View();
        }*/
        public IActionResult UpdateProfile()
        {
            return View();
        }
        [HttpPost]
        public IActionResult UpdateProfile(string email)
        {
            var files = Request.Form.Files;
            if (files.Count > 0)
            {
                string path = UploadProfile(files[0]);
                userService.UpdateProfile(email, path);
                return RedirectToAction("Index", "Home");
            }
            else
            {
                ModelState.AddModelError(string.Empty,"Please Select File !");
            }
            return View();
        }

        public string UploadProfile(IFormFile formFile)
        {
            var www = Environment.ContentRootPath;
            var fullpath = Path.Combine(www,"wwwroot","images",formFile.FileName);
            FileStream stream = new FileStream(fullpath,FileMode.Create);
            formFile.CopyTo(stream);
            return $"images/{formFile.FileName}";
        }
        public IActionResult Register()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Register(SignUp model)
        {
            if (ModelState.IsValid)
            {
                var result = userService.Register(model);
                if (result !=null)
                {
                    return RedirectToAction("VerifyUser");
                }
                else 
                {
                    ModelState.AddModelError(string.Empty,"Email is already Exist");
                    return View(model);
                }
            }
            /*return View();*//*
            return RedirectToAction("VerifyUser");*/
            return View(model);
        }
        public IActionResult VerifyUser()
        {
            return View();
        }
        [HttpPost]
        public IActionResult VerifyUser(string otp)
        {
            if (otp != null)
            {
                VerifyAccountEnum result = userService.VerifyAccount(otp);
                if (result == VerifyAccountEnum.OTPVARIFIED)
                {
                    return RedirectToAction("Login");
                }
                else
                {
                    ModelState.AddModelError(string.Empty, "Invalid OTP !");
                    return View();
                }
            }
            else 
            {
                ModelState.AddModelError(string.Empty,"Please Enter OTP");
                return View();
            }
        }
    }
}
