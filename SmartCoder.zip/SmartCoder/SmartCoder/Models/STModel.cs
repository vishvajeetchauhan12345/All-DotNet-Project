﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SmartCoder.Models
{
    public class STModel
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Gender { get; set; }
        public long Contact { get; set; }
        public string Course { get; set; }
        public LocationsM Location { get; set; }
    }
}
