﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SmartCoder.Models
{
    public class StudentDbOperation
    {
        private List<STModel> students;
        public StudentDbOperation()
        {
            students = new List<STModel>()
            {
                new STModel(){Id=1,Name="Vishvajeet",Gender="male",Contact=9648202105,Course="BCA" },
                new STModel(){Id=2,Name="Aditi",Gender="female",Contact=9645672105,Course="BCA" },
                new STModel(){Id=3,Name="Abhishek",Gender="male",Contact=9123202105,Course="B.Tech" },
                new STModel(){Id=4,Name="Chitra",Gender="female",Contact=9648203221,Course="BCA" },
                new STModel(){Id=5,Name="Shivani",Gender="female",Contact=9648207889,Course="MCA" }
            };
        }
        public List<STModel> GetStudents()
        {
            return this.students;
        }
        public STModel AddStudent(STModel obj)
        {
            this.students.Add(obj);
            return obj;
        }
    }
}
