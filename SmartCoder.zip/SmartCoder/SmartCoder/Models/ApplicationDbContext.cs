﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

namespace SmartCoder.Models
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) :base(options){}
        public DbSet<STModel> students { get; set; }
        public DbSet<LocationsM> LocationsM { get; set; }
        public DbSet<EmployeeM> employees { get; set; }
    }
}
