﻿using System;

namespace SmartCoder.Models
{
    internal class keyAttribute : Attribute
    {
       
    }
}