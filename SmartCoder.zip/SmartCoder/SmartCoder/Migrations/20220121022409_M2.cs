﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace SmartCoder.Migrations
{
    public partial class M2 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "LocationId",
                table: "students",
                type: "int",
                nullable: true);

            migrationBuilder.CreateTable(
                name: "LocationsM",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_LocationsM", x => x.Id);
                });

            migrationBuilder.CreateIndex(
                name: "IX_students_LocationId",
                table: "students",
                column: "LocationId");

            migrationBuilder.AddForeignKey(
                name: "FK_students_LocationsM_LocationId",
                table: "students",
                column: "LocationId",
                principalTable: "LocationsM",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_students_LocationsM_LocationId",
                table: "students");

            migrationBuilder.DropTable(
                name: "LocationsM");

            migrationBuilder.DropIndex(
                name: "IX_students_LocationId",
                table: "students");

            migrationBuilder.DropColumn(
                name: "LocationId",
                table: "students");
        }
    }
}
