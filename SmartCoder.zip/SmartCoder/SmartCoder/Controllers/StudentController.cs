﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using SmartCoder.Models;


namespace SmartCoder.Controllers
{
    public class StudentController : Controller
    {
        /*private StudentDbOperation dbOperation;*/
        private ApplicationDbContext dbContext;
        public StudentController(ApplicationDbContext _dbContext)
        {
            /*dbOperation = new StudentDbOperation();*/
            dbContext = _dbContext;
        }
        public IActionResult Index()
        {
            /*var students = dbOperation.GetStudents();*/
            /*var students = dbContext.students.ToList();*/
            var locations = dbContext.LocationsM.ToList();
            return View(locations);
        }
        public IActionResult StudentList(int id)
        {
            var students = dbContext.students.Where(e => e.Location.Id == id);
            return View(students);
        }
        public IActionResult StudentDetail(int id)
        {
            var detail = dbContext.students.SingleOrDefault(e=>e.Id==id);
            return View(detail);
        }
    }
}
