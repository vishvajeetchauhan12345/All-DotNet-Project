﻿using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using SmartCoder.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace SmartCoder.Controllers
{
    public class EmployeeController : Controller
    {
        private ApplicationDbContext dbContext;
        public IHostingEnvironment Environment { get; }
        public EmployeeController(ApplicationDbContext context,IHostingEnvironment environment)
        {
            dbContext = context;
        }
        public IActionResult Index()
        {
            var emps = dbContext.employees.ToList();
            return View(emps);
        }
        public IActionResult Create()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Create(EmployeeM employee)
        {
            
            var files=Request.Form.Files;
            string dbpath = string.Empty;
            if (files.Count > 0)
            {
                string path = Environment.WebRootPath;
                string FullPath = Path.Combine(path, "images", files[0].FileName);
                dbpath = "image/" + files[0].FileName;
                FileStream stream = new FileStream(FullPath,FileMode.Create);
                files[0].CopyTo(stream);
            }
            employee.Image = dbpath;
            dbContext.employees.Add(employee);
            dbContext.SaveChanges();
            return RedirectToAction("Index");
        }
    }
}
