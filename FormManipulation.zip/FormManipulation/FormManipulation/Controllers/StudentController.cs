﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FormManipulation.Models;
using Microsoft.AspNetCore.Hosting;
using System.IO;


namespace FormManipulation.Controllers
{
    public class StudentController : Controller
    {
        private AppDbContext db;

        public IHostingEnvironment Environment { get; }

        public StudentController(AppDbContext context ,IHostingEnvironment environment)
        {
            db = context;
            Environment = environment;
        }
        public IActionResult Index()
        {
            var st = db.students.ToList();
            return View(st);
        }
        public IActionResult Create()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Create(Student st)
        {
            var files = Request.Form.Files;
            string dbpath = string.Empty;
            if (files.Count > 0)
            {
                string path = Environment.WebRootPath;
                string fullpath = Path.Combine(path, "images", files[0].FileName);
                dbpath = "images/" + files[0].FileName;
                FileStream stream = new FileStream(fullpath, FileMode.Create);
                files[0].CopyTo(stream);
            }
            st.Image = dbpath;
            db.students.Add(st);
            db.SaveChanges();
            return RedirectToAction("Index");
        }
    }
}
