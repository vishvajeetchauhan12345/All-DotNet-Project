﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using Management.Models;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Hosting;
using System.IO;

namespace Management.Controllers
{
    public class CategoryController : Controller
    {
        public AppDbContex dbcon;
        public IHostingEnvironment Environment { get; }
        public CategoryController(AppDbContex context,IHostingEnvironment environment)
        {
            dbcon = context;
            Environment = environment;
        }
        public IActionResult Index()
        {
            var cat = dbcon.categories.ToList();
            return View(cat);
        }
        public IActionResult Create()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Create(Category category)
        {
            var files = Request.Form.Files;
            string dbpath = string.Empty;
            if (files.Count > 0)
            {
                string path = Environment.WebRootPath;
                string fullpath = Path.Combine(path, "products", files[0].FileName);
                dbpath = "products/" + files[0].FileName;
                FileStream stream = new FileStream(fullpath, FileMode.Create);
                files[0].CopyTo(stream);
            }
            category.Image = dbpath;
            dbcon.categories.Add(category);
            dbcon.SaveChanges();
            return RedirectToAction("Index");
        }
        public IActionResult Delete(int id)
        {
            var d1 = dbcon.categories.SingleOrDefault(e => e.Id == id);
            dbcon.categories.Remove(d1);
            dbcon.SaveChanges();
            return RedirectToAction("Index");
        }
        public IActionResult Update(int id)
        {
            var u = dbcon.categories.SingleOrDefault(e => e.Id == id);
            return View(u);
        }
        [HttpPost]
        public IActionResult Update(Category category)
        {
            var files = Request.Form.Files;
            string dbpath = string.Empty;
            if (files.Count > 0)
            {
                string path = Environment.WebRootPath;
                string fullpath = Path.Combine(path, "category", files[0].FileName);
                dbpath = "category/" + files[0].FileName;
                FileStream stream = new FileStream(fullpath, FileMode.Create);
                files[0].CopyTo(stream);
            }
            category.Image = dbpath;
            dbcon.categories.Update(category);
            dbcon.SaveChanges();
            return RedirectToAction("Index");
        }
    }
}
