﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using CoreProject2.Models;
using CoreProject2.Repository.Contract;

namespace CoreProject2.Repository.Service
{
    public class UserService : IUser
    {
        private AppDbContext dbContext;
        public UserService(AppDbContext context) 
        {
            dbContext = context;
        }

        public User CreateUser(User user)
        {
            
            dbContext.users.Add(user);
            dbContext.SaveChanges();
            return user;
        }

        public List<City> GetAllCity(int id)
        {
            var list = dbContext.cities.Where(e=>e.State.Id==id).ToList();
            return list;
        }

        public List<Country> GetAllCountry()
        { 
            var list=dbContext.countries.ToList();
            return list;
        }

        public List<State> GetAllStates(int id)
        {
            var list = dbContext.states.Where(e=>e.Country.Id==id).ToList();
            return list;
        }

        public List<UserViewModel> GetUsers()
        {
            var userData=dbContext.users.ToList();
            List<UserViewModel> list = new List<UserViewModel>();
            foreach (var item in userData)
            {
                /*var state = dbContext.states.Where(x => x.Id.ToString() == item.State).FirstOrDefault<State>();
                var country = dbContext.countries.Where(x => x.Id.ToString() == item.Country).FirstOrDefault<Country>();
                //var city = dbContext.cities.Where(x => x.Id.ToString() == item.City).FirstOrDefault<City>();*/
                var country = dbContext.countries.Find(Convert.ToInt32(item.Country));
                var state = dbContext.states.Find(Convert.ToInt32(item.State));
                var city = dbContext.cities.Find(Convert.ToInt32(item.City));
                UserViewModel user = new UserViewModel()
                {
                    Name = item.Name,
                    Gender = item.Gender,
                    Email = item.Email,
                    Country = country.Name,
                    State = state.Name,
                    City= city.Name,
                    Contact=item.Contact

                };
                list.Add(user);
            }
            
            return list; 
        }
    }
}
