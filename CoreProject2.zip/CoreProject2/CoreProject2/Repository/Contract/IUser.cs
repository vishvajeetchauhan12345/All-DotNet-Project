﻿using CoreProject2.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CoreProject2.Repository.Contract
{
    public interface IUser
    {
        List<UserViewModel> GetUsers();
        User CreateUser(User user);
        List<Country> GetAllCountry();
        List<State> GetAllStates(int id);
        List<City> GetAllCity(int id);
    }
}
