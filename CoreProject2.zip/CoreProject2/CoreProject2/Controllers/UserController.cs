﻿using CoreProject2.Models;
using CoreProject2.Repository.Contract;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CoreProject2.Controllers
{
    public class UserController : Controller
    {
        private IUser userService;
        public UserController(IUser service) 
        {
            userService = service;
        }
        public IActionResult Index() 
        {
            var collect = userService.GetUsers();
            return View(collect);
        }
        public IActionResult Create()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Create(User user)
        {
            var Custom = userService.CreateUser(user);
            return RedirectToAction("Index");
        }
        public IActionResult GetCountry()
        {
            var country = userService.GetAllCountry();
            return Json(country);
        }
        [HttpGet]
        public IActionResult GetState(int id)
        {
             var statelist = userService.GetAllStates(id);
             return Json(statelist);
        }
        [HttpGet]
        public IActionResult GetCity(int id)
        {
            var citylist = userService.GetAllCity(id);
            return Json(citylist);
        }
    }
}
