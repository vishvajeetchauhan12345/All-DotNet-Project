﻿using CoreProject1.Models;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace CoreProject1.Controllers
{
    public class UserController : Controller
    {
        private AppDbContext dbconn;

        private IHostingEnvironment Environment;

        public UserController(AppDbContext conn,IHostingEnvironment environment) 
        {
            dbconn = conn;
            Environment = environment;
        }
        //by deafult view page user list
        public IActionResult Index()
        {
            var users = dbconn.users.ToList();
            return View(users);
        }
        
        public IActionResult Create()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Create(User user) 
        {
            var files = Request.Form.Files;
            string dbpath = string.Empty;
            if (files.Count > 0)
            {
                string path = Environment.WebRootPath;
                string fullpath = Path.Combine(path,"images", files[0].FileName);
                dbpath = "images/" + files[0].FileName;
                FileStream stream = new FileStream(fullpath, FileMode.Create);
                files[0].CopyTo(stream);
            }
            user.Image = dbpath;
          
                dbconn.users.Add(user);
                dbconn.SaveChanges();
                return RedirectToAction("Index");
            
        }
        [HttpGet]
        public IActionResult Delete(int id)
        {
            var user = dbconn.users.SingleOrDefault(e=>e.Id==id);
            dbconn.users.Remove(user);
            dbconn.SaveChanges();
            return RedirectToAction("Index");
        }
        [HttpGet]
        public IActionResult Update(int id)
        {
            var updateuser = dbconn.users.SingleOrDefault(e=>e.Id==id);
            return View(updateuser);
        }
        [HttpPost]
        public IActionResult Update(User user)
        {
            var files = Request.Form.Files;
            string dbpath = string.Empty;
            if (files.Count > 0)
            {
                string path = Environment.WebRootPath;
                string fullpath = Path.Combine(path, "images", files[0].FileName);
                dbpath = "images/" + files[0].FileName;
                FileStream stream = new FileStream(fullpath, FileMode.Create);
                files[0].CopyTo(stream);
            }
            user.Image = dbpath;
            dbconn.users.Update(user);
            dbconn.SaveChanges();
            return RedirectToAction("Index");   
        }
        [HttpGet]
        public IActionResult Display(int id)
        {
            var user = dbconn.users.SingleOrDefault(e=>e.Id==id);
            return View(user);
        }
    }
}
