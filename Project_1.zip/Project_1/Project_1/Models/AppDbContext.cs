﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Project_1.Models;

namespace Project_1.Models
{
    public class AppDbContext:DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext>option):base(option) { }
        public DbSet<Customer> customers { get; set; }
        public DbSet<Company> companies { get; set; }
    }
}
