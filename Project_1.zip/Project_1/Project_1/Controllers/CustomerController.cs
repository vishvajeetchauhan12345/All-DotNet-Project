﻿using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Project_1.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace Project_1.Controllers
{
    public class CustomerController : Controller
    {
        private AppDbContext dbcon;
        public IHostingEnvironment Environment { get; set; }
        public CustomerController(AppDbContext con, IHostingEnvironment environment)
        {
            dbcon = con;
            Environment = environment;
        }
        public IActionResult Index()
        {
            var Listcustomer = dbcon.customers.ToList();
            return View(Listcustomer);
        }
        public IActionResult CreateCustomer()
        {
            return View();
        }
        [HttpPost]
        public IActionResult CreateCustomer(Customer customer)
        {
            var files = Request.Form.Files;
            string dbpath = string.Empty;
            if (files.Count > 0)
            {
                string path = Environment.WebRootPath;
                string fullpath = Path.Combine(path, "images", files[0].FileName);
                dbpath = "images/" + files[0].FileName;
                FileStream stream = new FileStream(fullpath, FileMode.Create);
                files[0].CopyTo(stream);
            }
            customer.IsActive = true;
            customer.Image = dbpath;
            Company c = new Company()
            {
                c.Name = customer.Company
            };
            dbcon.companies.Add(c);
            customer.Company = c.Name;
            dbcon.customers.Add(customer);
            dbcon.SaveChanges();
            return RedirectToAction("Index");
        }
        [HttpGet]
        public IActionResult DeleteCustomer(int id)
        {
            var deletecustomerNow = dbcon.customers.SingleOrDefault(e => e.Id == id);
            dbcon.customers.Remove(deletecustomerNow);
            dbcon.SaveChanges();
            return RedirectToAction("Index");
        }
        [HttpGet]
        public IActionResult UpdateCustomer(int id)
        {
            var updatecustomer = dbcon.customers.SingleOrDefault(e => e.Id == id);
            return View(updatecustomer);
        }

        [HttpPost]
        public IActionResult UpdateCustomer(Customer customer)
        {
            var files = Request.Form.Files;
            string dbpath = string.Empty;
            if (files.Count > 0)
            {
                string path = Environment.WebRootPath;
                string fullpath = Path.Combine(path, "images", files[0].FileName);
                dbpath = "images/" + files[0].FileName;
                FileStream stream = new FileStream(fullpath, FileMode.Create);
                files[0].CopyTo(stream);
            }
            customer.Image = dbpath;
            dbcon.customers.Update(customer);
            dbcon.SaveChanges();
            return RedirectToAction("Index");  
        }
        [HttpGet]
        public IActionResult ViewCustomer(int id)
        {
            var viewdata = dbcon.customers.SingleOrDefault(e=>e.Id==id);
            return View(viewdata);
        }
        // company not implemented yet
        /*public IActionResult CompanyIndex()
        {
            var com = dbcon.companies.ToList();
            return View(com);
        }*/

        public IActionResult CreateCompany()
        {
            return View();
        }
        [HttpPost]
        public IActionResult CreateCompany(Company company)
        {
            var files = Request.Form.Files;
            string dbpath = string.Empty;
            if (files.Count > 0)
            {
                string path = Environment.WebRootPath;
                string fullpath = Path.Combine(path, "Company", files[0].FileName);
                dbpath = "Company/" + files[0].FileName;
                FileStream stream = new FileStream(fullpath, FileMode.Create);
                files[0].CopyTo(stream);
            }
            Company.Image = dbpath;
            dbcon.companies.Add(company);
            dbcon.SaveChanges();
            return RedirectToAction("Index");
        }
    }
}
