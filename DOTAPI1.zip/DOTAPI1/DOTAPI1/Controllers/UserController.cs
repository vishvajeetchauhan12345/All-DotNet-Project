﻿using DOTAPI1.Models;
using DOTAPI1.Respository.Contract;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DOTAPI1.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        private IUser userService;
        public UserController(IUser user)
        {
            userService = user;
        }
        [HttpGet]
        [Route("GetAllUser")]
        public IActionResult GetAllUser()
        {
            var result = userService.GetUsers();
            if (result.Count > 0)
            {
                return Ok(result);
            }
            else
            {
                return NotFound("User Not Reachable");
            }
        }
        [HttpGet]
        [Route("GetUserById/{id}")]
        public IActionResult GetUserById(int id)
        {
            var result = userService.GetUserById(id);
            if (result != null)
            {
                return Ok(result);
            }
            else
            {
                return NotFound("User Not Found");
            }
        }
        [HttpPost]
        [Route("CreateUser")]
        public IActionResult Post(User user)
        {
            var result = userService.PostUser(user);
            if (result != null)
            {
                return Ok(result);
            }
            else
            {
                return Ok();
            }
        }
        [HttpDelete]
        [Route("DeleteUser/{id}")]
        public IActionResult Delete(int id)
        {
            if (id == 0)
            {
                return BadRequest();
            }
            else
            {
                var result = userService.DeleteUser(id);
                if (result != null)
                {
                    return Ok();
                }
                else
                {
                    return NotFound();
                }
            }
        }
        [HttpPut]
        [Route("UpdateUser")]
        public IActionResult UpdateUser(User user)
        {
            if (user == null)
            {
                return BadRequest();
            }
            else
            {
                var result = userService.UpdateUser(user);
                if (result != null)
                {
                    return Ok();
                }
                else 
                {
                    return NotFound();
                }
            }
        }
    }
}
