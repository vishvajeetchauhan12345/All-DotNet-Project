﻿using DOTAPI1.Contracts.Request;
using DOTAPI1.Contracts.Response;
using DOTAPI1.Respository.Contract;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DOTAPI1.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CustomController : ControllerBase
    {
        private ICustom customService;
        public CustomController(ICustom custom)
        {
            customService = custom;
        }
        [HttpPost]
        [Route("SignIn")]
        public IActionResult SignIn(SignInModel model)
        {
            if (model != null)
            {
                var user = customService.SignIn(model);
                var apiresponse = new ApiResponse();
                if (user == null)
                {
                    //User Not Found
                    apiresponse.Ok = false;
                    apiresponse.Status = 404;
                    apiresponse.Message = "Invalid crediential login !";
                    return Ok(apiresponse);
                }
                else
                {
                    //success
                    apiresponse.Ok = true;
                    apiresponse.Status = 200;
                    apiresponse.Message = "Successfull";
                    apiresponse.Data = user;
                    apiresponse.Token = "?";
                    return Ok(apiresponse);
                }
            }
            else
            {
                return BadRequest();
            }
        
        }
        [HttpPost]
        [Route("SignUp")]
        public IActionResult SignUp(SignUpModel model)
        {
            if (model != null)
            {
                var user = customService.SignUp(model);
                var apiresponse = new ApiResponse();
              
                    //success
                    apiresponse.Ok = true;
                    apiresponse.Status = 200;
                    apiresponse.Message = "User created Successfully";
                    apiresponse.Data = user;
                    return Ok(apiresponse); 
            }
            else
            {
                return BadRequest();
            }
        }
    }
}
