﻿using DOTAPI1.Contracts.Request;
using DOTAPI1.Models;
using DOTAPI1.Respository.Contract;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DOTAPI1.Respository.Service
{
    public class CustomService : ICustom
    {
        private AppDbContext dbconn;
        public CustomService(AppDbContext con) 
        {
            dbconn = con;
        }
        public Custom SignIn(SignInModel model)
        {
            var d = dbconn.customs.SingleOrDefault(e=>e.Email==model.Email && e.Password==model.Password);
            if (d!=null)
            {
                return d;
            }
            else
            {
                return null;
            }
        }

        public Custom SignUp(SignUpModel model)
        {
            var newUser = new Custom()
            {
                Name = model.Name,
                Email = model.Email,
                Password=model.Password,
                Contact=model.Contact,
                Gender=model.Gender
            };
            dbconn.customs.Add(newUser);
            dbconn.SaveChanges();
            return newUser;
        }
    }
}
