﻿using DOTAPI1.Models;
using DOTAPI1.Respository.Contract;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DOTAPI1.Respository.Service
{
    public class UserService : IUser
    {
        private AppDbContext dbcon;
        public UserService(AppDbContext con)
        {
            dbcon = con;
        }

        public User DeleteUser(int id)
        {
            var d = dbcon.users.SingleOrDefault(e => e.Id == id);
            if (d != null)
            {
                dbcon.users.Remove(d);
                dbcon.SaveChanges();
                return d;
            }
            else 
            {
                return null;
            }
           
        }

        public User GetUserById(int Id)
        {
            var d = dbcon.users.SingleOrDefault(e => e.Id == Id);
            return d;
        }

        public List<User> GetUsers()
        {
            return dbcon.users.ToList();
        }

        public User PostUser(User user)
        {
            dbcon.users.Add(user);
            dbcon.SaveChanges();
            return user;
        }

        public User UpdateUser(User user)
        {
            var u = dbcon.users.SingleOrDefault(e=>e.Id==user.Id);
            if (u != null)
            {
                u.Name = user.Name;
                u.Address = user.Address;
                u.Contact = user.Contact;
                dbcon.users.Update(user);
                dbcon.SaveChanges();
                return user;
            }
            else
            {
                return null;
            }
            
        }
    }
}
