﻿using DOTAPI1.Contracts.Request;
using DOTAPI1.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DOTAPI1.Respository.Contract
{
   public interface ICustom
    {
        Custom SignIn(SignInModel model);

        Custom SignUp(SignUpModel model);
    }
}
