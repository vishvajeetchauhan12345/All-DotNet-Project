﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DOTAPI1.Models;

namespace DOTAPI1.Respository.Contract
{
    public interface IUser
    {
        List<User> GetUsers();
        User PostUser(User user);
        User GetUserById(int Id);
        User DeleteUser(int id);
        User UpdateUser(User user);
    }
}
