﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using TestMultiSelective1.Models;

namespace TestMultiSelective1.Controllers
{
    public class HomeController : Controller
    {
        
        private AppDbContext dbcon;

        public HomeController(AppDbContext con)
        {
            dbcon = con;
        }

        public IActionResult Index()
        {
            List<SelectListItem> customerList = GetCustomers();
            return View(customerList);
        }
        [HttpPost]
        public IActionResult Index(string[] customers)
        {
            List<SelectListItem> customerList = GetCustomers();
            ViewBag.Message = "";
            foreach (string customerId in customers)
            {
                SelectListItem selectedItem = customerList.Find(p => p.Value == customerId);
                ViewBag.Message += "Name: " + selectedItem.Text;
                ViewBag.Message += "\\nID: " + selectedItem.Value;
                ViewBag.Message += "\\n";
            }
            return View(customerList);
        }
        private List<SelectListItem> GetCustomers()
        {
           /* AppDbContext entities = new AppDbContext();*/
            List<SelectListItem> customerList = (from p in dbcon.customers.AsEnumerable()
                                                 select new SelectListItem
                                                 {
                                                     Text = p.Name,
                                                     Value = p.Id.ToString()
                                                 }).ToList();

            //Add Default Item at First Position.
            customerList.Insert(0, new SelectListItem { Text = "--Select Customer--", Value = "" });

            return customerList;
        }
        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
