﻿using System;

namespace FabbonacciSeries
{
    class Program
    {
        public void Fabonacci(int n)
        {
            int first=0, second=1,fab=0;
            Console.WriteLine("-------------------------Fabonacci series---------------------------");
            for (int i=1;i<=n;i++)
            {
                if (i == 1)
                {
                    fab = first;
                    Console.Write(" "+fab);
                }
                else if (i == 2)
                {
                    fab = second;
                    Console.Write(" "+fab);
                }
                else 
                {
                    fab = first + second;
                    Console.Write(" "+fab);
                    first = second;
                    second = fab;
                }
            }
        
        }
        static void Main(string[] args)
        {
            int n;
            Console.WriteLine("Enter a N term of fabonnacci series:");
            n = int.Parse(Console.ReadLine());
            Program obj = new Program();
            obj.Fabonacci(n);
        }
    }
}
